/* ══════════════════════════════════════════════════════
   LAGRO BISTRO — Cart (included on every page)
══════════════════════════════════════════════════════ */

const Cart = {

  async getCount() {
    try {
      const res = await fetch('api/cart.php');
      if (!res.ok) return 0;
      const data = await res.json();
      return data.count || 0;
    } catch { return 0; }
  },

  async updateBadge() {
    const count = await this.getCount();
    const badge = document.getElementById('cart-badge');
    if (!badge) return;
    if (count > 0) {
      badge.textContent = count > 99 ? '99+' : count;
      badge.style.display = 'flex';
      // Bump animation
      badge.classList.remove('bump');
      void badge.offsetWidth;
      badge.classList.add('bump');
      setTimeout(() => badge.classList.remove('bump'), 300);
    } else {
      badge.style.display = 'none';
    }
  },

  async add(productId, qty = 1, customization = '') {
    try {
      await fetch('api/cart.php', {
        method:  'POST',
        headers: { 'Content-Type': 'application/json' },
        body:    JSON.stringify({ product_id: productId, quantity: qty, customization })
      });
      await this.updateBadge();
    } catch(e) { console.error('Cart.add:', e); }
  },

  async remove(productId) {
    try {
      await fetch('api/cart.php', {
        method:  'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body:    JSON.stringify({ product_id: productId })
      });
      await this.updateBadge();
    } catch(e) { console.error('Cart.remove:', e); }
  },

  async updateQty(productId, quantity) {
    try {
      await fetch('api/cart.php', {
        method:  'PUT',
        headers: { 'Content-Type': 'application/json' },
        body:    JSON.stringify({ product_id: productId, quantity })
      });
      await this.updateBadge();
    } catch(e) { console.error('Cart.updateQty:', e); }
  },

  clearBadge() {
    const badge = document.getElementById('cart-badge');
    if (badge) badge.style.display = 'none';
  }
};

// Sync badge on every page load
document.addEventListener('DOMContentLoaded', () => Cart.updateBadge());
