/* ══════════════════════════════════════════════════════
   LAGRO BISTRO — Main Application
══════════════════════════════════════════════════════ */

let currentUser = null;
let allProducts  = [];

// SVG icon paths for use in JS-rendered HTML
const ICONS = {
  star:  'icons/star_24dp_E3E3E3_FILL0_wght400_GRAD0_opsz24.svg',
  check: 'icons/check_24dp_E3E3E3_FILL0_wght400_GRAD0_opsz24.svg',
  close: 'icons/close_24dp_E3E3E3_FILL0_wght400_GRAD0_opsz24.svg',
  cart:  'icons/shopping_cart_24dp_E3E3E3_FILL0_wght400_GRAD0_opsz24.svg',
  dark:  'icons/dark_mode_24dp_E3E3E3_FILL0_wght400_GRAD0_opsz24.svg',
  light: 'icons/light_mode_24dp_E3E3E3_FILL0_wght400_GRAD0_opsz24.svg',
};

/* ── BOOT ─────────────────────────────────────────── */
document.addEventListener('DOMContentLoaded', async () => {
  await restoreSession();
  await loadProducts();
  navigate('home');
});

async function restoreSession() {
  try {
    const res  = await fetch('api/session.php');
    const data = await res.json();
    if (data.user) {
      currentUser = data.user;
      applyTheme(data.theme || 'dark');
      updateNav();
      Cart.updateBadge();
    }
  } catch(e) {}
}

async function loadProducts() {
  try {
    const res   = await fetch('api/products.php');
    allProducts = await res.json();
  } catch { allProducts = []; }
}

/* ── THEME ────────────────────────────────────────── */
function applyTheme(theme) {
  document.documentElement.dataset.theme = theme;
  const icon = document.getElementById('theme-icon');
  if (!icon) return;
  icon.src = theme === 'light' ? ICONS.light : ICONS.dark;
}

function toggleTheme() {
  const isDark   = document.documentElement.dataset.theme === 'dark';
  const newTheme = isDark ? 'light' : 'dark';
  applyTheme(newTheme);
  if (currentUser) {
    fetch('api/session.php', {
      method:  'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body:    JSON.stringify({ theme: newTheme })
    });
  }
}

/* ── NAV ──────────────────────────────────────────── */
function updateNav() {
  const cartBtn   = document.getElementById('cart-btn');
  const navOrders = document.getElementById('nav-orders');
  const navStocks = document.getElementById('nav-stocks');
  const navMod    = document.getElementById('nav-moderator');
  const authArea  = document.getElementById('auth-area');

  if (currentUser) {
    cartBtn.style.display   = 'flex';
    if (currentUser.role === 'admin' || currentUser.role === 'owner') {
      navOrders.style.display = 'block';
      navStocks.style.display = 'block';
      navMod.style.display    = 'block';
    }
    if (currentUser.role === 'moderator') {
      navMod.style.display = 'block';
    }
    authArea.innerHTML = `
      <div class="user-menu-wrap">
        <button class="btn-primary" onclick="toggleUserMenu(event)"
                style="padding:7px 14px;font-size:13px">
          ${esc(currentUser.full_name.split(' ')[0])} ▾
        </button>
        <div class="user-menu" id="user-menu">
          <button onclick="navigate('profile');closeUserMenu()">Profile</button>
          <button class="danger" onclick="doLogout()">Logout</button>
        </div>
      </div>`;
  } else {
    cartBtn.style.display   = 'none';
    navOrders.style.display = 'none';
    navStocks.style.display = 'none';
    navMod.style.display    = 'none';
    authArea.innerHTML = `
      <button class="btn-primary" onclick="navigate('login')"
              style="padding:8px 18px;font-size:13px">Login</button>`;
  }
}

function toggleUserMenu(e) {
  e.stopPropagation();
  document.getElementById('user-menu')?.classList.toggle('open');
}
function closeUserMenu() {
  document.getElementById('user-menu')?.classList.remove('open');
}
document.addEventListener('click', closeUserMenu);

async function doLogout() {
  await fetch('api/session.php', { method: 'DELETE' });
  currentUser = null;
  Cart.clearBadge();
  updateNav();
  showToast('Logged out successfully');
  navigate('home');
}

/* ── ROUTER ───────────────────────────────────────── */
const PAGES = {
  home:      renderHome,
  menu:      renderMenu,
  cart:      renderCart,
  login:     renderLogin,
  signup:    renderSignup,
  profile:   renderProfile,
  admin:     renderAdmin,
  stocks:    renderStocks,
  moderator: renderModerator,
};

function navigate(page) {
  closeUserMenu();
  document.querySelectorAll('.nav-link').forEach(l => l.classList.remove('active'));
  const app = document.getElementById('app');
  app.innerHTML = '';
  if (PAGES[page]) PAGES[page]();
  window.scrollTo(0, 0);
}

/* ── TOAST ────────────────────────────────────────── */
let _toastTimer;
function showToast(msg, type = 'success') {
  const t   = document.getElementById('toast');
  const ico = type === 'error'
    ? `<img src="${ICONS.close}" alt="">`
    : `<img src="${ICONS.check}" alt="">`;
  t.innerHTML     = ico + esc(msg);
  t.className     = `toast toast-${type}`;
  t.style.display = 'flex';
  clearTimeout(_toastTimer);
  _toastTimer = setTimeout(() => t.style.display = 'none', 3200);
}

/* ── MODAL ────────────────────────────────────────── */
function openModal(html) {
  document.getElementById('modal-content').innerHTML = html;
  document.getElementById('modal-overlay').classList.add('open');
}
function closeModal() {
  document.getElementById('modal-overlay').classList.remove('open');
}

/* ── ESCAPE HELPER ────────────────────────────────── */
function esc(str = '') {
  return String(str)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;')
    .replace(/>/g, '&gt;').replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function statusClass(s) {
  const map = {
    pending:   'status-pending',
    confirmed: 'status-confirmed',
    preparing: 'status-preparing',
    ready:     'status-ready',
    completed: 'status-completed',
    cancelled: 'status-cancelled',
  };
  return map[s] || '';
}

/* ══════════════════════════════════════════════════════
   HOME PAGE
══════════════════════════════════════════════════════ */
function renderHome() {
  const best = allProducts.filter(p => p.is_best_seller == 1 && p.is_available == 1);
  document.getElementById('app').innerHTML = `
    <div class="hero">
      <div class="hero-content">
        <h1 class="hero-title">WELCOME TO<br>
          THE BISTRO WEBSITE</h1>
        <p class="hero-sub">Enjoy our best coffee and treats — freshly made every day!</p>
        <button class="btn-primary" onclick="navigate('menu')"
                style="padding:14px 32px;font-size:15px">Discover</button>
      </div>
    </div>

    <section class="page-wrap">
      <div class="section-header">
        <p class="section-tag">OUR FAVORITES</p>
        <h2 class="section-title">Best Sellers</h2>
        <div class="section-divider"></div>
      </div>
      <div class="products-grid">
        ${best.length
          ? best.map(p => productCardHTML(p)).join('')
          : '<p style="color:var(--sub);grid-column:1/-1;text-align:center;padding:40px 0">No best sellers configured yet.</p>'}
      </div>
    </section>

    <div style="background:var(--card);border-top:1px solid var(--border);padding:60px 40px">
      <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:32px;
                  max-width:900px;margin:0 auto;text-align:center">
        ${[['Fresh Daily','All items made fresh every morning'],
           ['Fast Pickup','Quick preparation for every order'],
           ['Made with Love','Every dish crafted with passion']].map(([t,d]) => `
          <div>
            <h3 style="color:var(--accent);font-size:17px;font-weight:700;margin-bottom:8px">${t}</h3>
            <p style="color:var(--sub);font-size:14px;line-height:1.5">${d}</p>
          </div>`).join('')}
      </div>
    </div>`;
}

/* ══════════════════════════════════════════════════════
   MENU PAGE
══════════════════════════════════════════════════════ */
function renderMenu() {
  const available  = allProducts.filter(p => p.is_available == 1);
  const categories = [...new Set(available.map(p => p.category_name))];

  document.getElementById('app').innerHTML = `
    <div class="page-wrap">
      <div class="section-header">
        <p class="section-tag">EXPLORE</p>
        <h2 class="section-title">Our Menu</h2>
        <div class="section-divider"></div>
      </div>
      <div style="display:flex;gap:8px;justify-content:center;margin-bottom:36px;flex-wrap:wrap">
        <button class="filter-btn active" onclick="filterMenu('All',this)">All</button>
        ${categories.map(c =>
          `<button class="filter-btn" onclick="filterMenu('${esc(c)}',this)">${esc(c)}</button>`
        ).join('')}
      </div>
      <div class="products-grid" id="menu-grid">
        ${available.length
          ? available.map(p => productCardHTML(p)).join('')
          : '<p style="color:var(--sub);grid-column:1/-1;text-align:center;padding:40px">No items available.</p>'}
      </div>
    </div>`;
}

function filterMenu(cat, btn) {
  document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  const filtered = cat === 'All'
    ? allProducts.filter(p => p.is_available == 1)
    : allProducts.filter(p => p.category_name === cat && p.is_available == 1);
  document.getElementById('menu-grid').innerHTML = filtered.length
    ? filtered.map(p => productCardHTML(p)).join('')
    : '<p style="color:var(--sub);grid-column:1/-1;text-align:center;padding:40px">No items in this category.</p>';
}

/* ── PRODUCT CARD ─────────────────────────────────── */
function productCardHTML(p) {
  const qty = parseInt(p.stock_quantity);
  const imgContent = p.image_path
    ? `<img src="${esc(p.image_path)}" alt="${esc(p.name)}">`
    : `<div style="font-size:14px;color:var(--sub);text-align:center;padding:40px 20px">Product Image</div>`;

  return `
    <div class="product-card">
      <div class="product-image">
        ${imgContent}
        ${p.is_best_seller == 1
          ? `<span class="product-badge badge-best">
               <img src="${ICONS.star}" alt=""> BEST
             </span>` : ''}
        ${qty === 0
          ? `<span class="product-badge badge-out">
               <img src="${ICONS.close}" alt="" style="filter:none"> OUT OF STOCK
             </span>`
          : qty < 10
          ? `<span class="product-badge badge-low">LOW STOCK</span>` : ''}
      </div>
      <div class="product-info">
        <p class="product-name">${esc(p.name)}</p>
        <p class="product-desc">${esc(p.description || '')}</p>
        <div class="product-footer">
          <span class="product-price">₱${parseFloat(p.price).toFixed(2)}</span>
          ${qty > 0
            ? `<button class="btn-primary"
                       onclick="addToCartBtn(${p.id},'${esc(p.name)}')"
                       style="padding:8px 16px;font-size:12px">Add to Cart</button>`
            : `<button class="btn-primary" disabled
                       style="padding:8px 16px;font-size:12px">Sold Out</button>`}
        </div>
      </div>
    </div>`;
}

async function addToCartBtn(productId, name) {
  if (!currentUser) {
    showToast('Please login to add items', 'error');
    navigate('login');
    return;
  }
  await Cart.add(productId, 1, '');
  showToast(`${name} added to cart!`);
}

/* ══════════════════════════════════════════════════════
   CART PAGE
══════════════════════════════════════════════════════ */
function openCart() {
  const sidebar = document.getElementById('cart-sidebar');
  const overlay = document.getElementById('cart-overlay');
  sidebar.classList.add('open');
  overlay.classList.add('open');
  loadCartSidebar();
}

function closeCart() {
  const sidebar = document.getElementById('cart-sidebar');
  const overlay = document.getElementById('cart-overlay');
  sidebar.classList.remove('open');
  overlay.classList.remove('open');
}

async function loadCartSidebar() {
  if (!currentUser) { navigate('login'); return; }
  const content = document.getElementById('cart-content');
  content.innerHTML = '<div style="padding:20px;text-align:center;color:var(--sub)">Loading cart…</div>';

  const res   = await fetch('api/cart.php');
  const data  = await res.json();
  const items = data.items || [];

  if (!items.length) {
    content.innerHTML = `
      <div style="text-align:center;padding:40px 20px">
        <h3 style="color:var(--text);margin-bottom:12px">Your cart is empty</h3>
        <button class="btn-primary" onclick="closeCart();navigate('menu')"
                style="padding:10px 20px;font-size:14px">Browse Menu</button>
      </div>`;
    return;
  }

  const subtotal = items.reduce((s, i) => s + parseFloat(i.price) * i.quantity, 0);

  content.innerHTML = `
    <div id="cart-items" style="margin-bottom:20px">
      ${items.map(item => `
        <div class="card" style="display:flex;align-items:center;gap:12px;margin-bottom:10px;padding:12px">
          <div style="width:50px;height:50px;border-radius:8px;overflow:hidden;flex-shrink:0;
                      background:linear-gradient(135deg,#2a1a0a,#1a0d05);
                      display:flex;align-items:center;justify-content:center">
            ${item.image_path
              ? `<img src="${esc(item.image_path)}" style="width:100%;height:100%;object-fit:cover">`
              : '<span style="font-size:20px">Product Image</span>'}
          </div>
          <div style="flex:1;min-width:0">
            <p style="font-weight:700;color:var(--text);font-size:13px;margin-bottom:2px">
              ${esc(item.name)}</p>
            <p style="color:var(--accent);font-weight:700;font-size:12px">
              ₱${parseFloat(item.price).toFixed(2)}</p>
          </div>
          <div style="display:flex;align-items:center;gap:4px">
            <button onclick="cartUpdateQty(${item.product_id},${item.quantity - 1})"
                    style="background:none;border:1px solid var(--border);border-radius:4px;
                           width:24px;height:24px;cursor:pointer;color:var(--text);font-size:14px;
                           display:flex;align-items:center;justify-content:center;font-family:inherit">−</button>
            <span style="color:var(--text);font-weight:700;min-width:18px;text-align:center;font-size:12px">
              ${item.quantity}</span>
            <button onclick="cartUpdateQty(${item.product_id},${item.quantity + 1})"
                    style="background:none;border:1px solid var(--border);border-radius:4px;
                           width:24px;height:24px;cursor:pointer;color:var(--text);font-size:14px;
                           display:flex;align-items:center;justify-content:center;font-family:inherit">+</button>
          </div>
          <button onclick="cartRemove(${item.product_id})"
                  style="background:rgba(220,0,50,.1);border:1px solid rgba(220,0,50,.3);
                         border-radius:4px;width:28px;height:28px;cursor:pointer;
                         display:flex;align-items:center;justify-content:center;flex-shrink:0;font-size:16px">×</button>
        </div>`).join('')}
    </div>

    <div style="border-top:1px solid var(--border);padding-top:16px;margin-bottom:16px">
      <div style="display:flex;justify-content:space-between;margin-bottom:8px;color:var(--text)">
        <span>Subtotal</span>
        <span style="font-weight:700">₱${subtotal.toFixed(2)}</span>
      </div>
      <div style="display:flex;justify-content:space-between;color:var(--accent);font-weight:700;font-size:16px">
        <span>Total</span>
        <span>₱${subtotal.toFixed(2)}</span>
      </div>
    </div>

    <button class="btn-primary" onclick="proceedToCheckout()"
            style="width:100%;padding:12px;font-size:14px;margin-bottom:8px">Checkout</button>
    <button class="btn-outline" onclick="closeCart();navigate('menu')"
            style="width:100%;padding:10px;font-size:13px">Continue Shopping</button>`;
}

function proceedToCheckout() {
  closeCart();
  navigate('checkout');
}

  const subtotal = items.reduce((s, i) => s + parseFloat(i.price) * i.quantity, 0);

  app.innerHTML = `
    <div class="page-wrap" style="max-width:1020px">
      <h2 style="font-size:26px;font-weight:800;color:var(--text);margin-bottom:28px">🛒 Your Cart</h2>
      <div style="display:grid;grid-template-columns:1fr 360px;gap:24px;align-items:start">

        <!-- Items list -->
        <div id="cart-items">
          ${items.map(item => `
            <div class="card" style="display:flex;align-items:center;gap:14px;
                                     margin-bottom:12px;padding:16px">
              <div style="width:58px;height:58px;border-radius:10px;overflow:hidden;flex-shrink:0;
                          background:linear-gradient(135deg,#2a1a0a,#1a0d05);
                          display:flex;align-items:center;justify-content:center">
                ${item.image_path
                  ? `<img src="${esc(item.image_path)}"
                          style="width:100%;height:100%;object-fit:cover">`
                  : '<span style="font-size:26px">🍽️</span>'}
              </div>
              <div style="flex:1;min-width:0">
                <p style="font-weight:700;color:var(--text);font-size:14px;margin-bottom:2px">
                  ${esc(item.name)}</p>
                <p style="color:var(--accent);font-weight:700;font-size:13px">
                  ₱${parseFloat(item.price).toFixed(2)}</p>
              </div>
              <div style="display:flex;align-items:center;gap:6px">
                <button onclick="cartUpdateQty(${item.product_id},${item.quantity - 1})"
                        style="background:none;border:1px solid var(--border);border-radius:6px;
                               width:28px;height:28px;cursor:pointer;color:var(--text);font-size:18px;
                               display:flex;align-items:center;justify-content:center;
                               font-family:inherit">−</button>
                <span style="color:var(--text);font-weight:700;min-width:22px;text-align:center">
                  ${item.quantity}</span>
                <button onclick="cartUpdateQty(${item.product_id},${item.quantity + 1})"
                        style="background:none;border:1px solid var(--border);border-radius:6px;
                               width:28px;height:28px;cursor:pointer;color:var(--text);font-size:18px;
                               display:flex;align-items:center;justify-content:center;
                               font-family:inherit">+</button>
              </div>
              <span style="color:var(--accent);font-weight:700;min-width:72px;text-align:right">
                ₱${(parseFloat(item.price) * item.quantity).toFixed(2)}
              </span>
              <button onclick="cartRemove(${item.product_id})"
                      style="background:rgba(220,0,50,.1);border:1px solid rgba(220,0,50,.3);
                             border-radius:6px;width:34px;height:34px;cursor:pointer;
                             display:flex;align-items:center;justify-content:center;flex-shrink:0">
                <img src="${ICONS.close}" alt="Remove"
                     style="width:16px;height:16px;filter:invert(40%) sepia(80%) saturate(600%) hue-rotate(310deg)">
              </button>
            </div>`).join('')}
        </div>

        <!-- Summary sidebar -->
        <div class="card">
          <h3 style="font-size:17px;font-weight:700;color:var(--text);margin-bottom:20px">
            Order Summary
          </h3>

          <div class="form-group">
            <label class="form-label">Payment Method</label>
            <select id="pay-method" class="form-input">
              <option value="cash">💵 Cash on Pickup</option>
              <option value="gcash">📱 GCash / E-Wallet</option>
              <option value="credit_card">💳 Credit Card</option>
              <option value="debit_card">🏦 Debit Card</option>
            </select>
          </div>

          <div class="form-group">
            <label class="form-label">Customer Notes</label>
            <textarea id="order-notes" class="form-input"
                      style="min-height:80px;resize:vertical"
                      placeholder="Special requests, allergies, etc…"></textarea>
          </div>

          <div style="border-top:1px solid var(--border);padding-top:16px;margin-bottom:20px">
            <div style="display:flex;justify-content:space-between;margin-bottom:6px">
              <span style="color:var(--sub);font-size:14px">Subtotal</span>
              <span style="color:var(--text);font-weight:600">₱${subtotal.toFixed(2)}</span>
            </div>
            <div style="display:flex;justify-content:space-between;margin-top:12px;
                        padding-top:12px;border-top:1px solid var(--border)">
              <span style="color:var(--text);font-weight:700;font-size:16px">Total</span>
              <span style="color:var(--accent);font-weight:800;font-size:20px">
                ₱${subtotal.toFixed(2)}
              </span>
            </div>
          </div>

          <button class="btn-primary" onclick="doPlaceOrder()"
                  style="width:100%;padding:14px;font-size:15px">
            Place Order →
          </button>
        </div>
      </div>
    </div>`;
}

async function cartUpdateQty(pid, qty) {
  await Cart.updateQty(pid, qty);
  renderCart();
}
async function cartRemove(pid) {
  await Cart.remove(pid);
  renderCart();
}

async function doPlaceOrder() {
  const payment = document.getElementById('pay-method').value;
  const notes   = document.getElementById('order-notes').value.trim();

  const res   = await fetch('api/cart.php');
  const data  = await res.json();
  const items = data.items || [];
  if (!items.length) return;

  const subtotal = items.reduce((s, i) => s + parseFloat(i.price) * i.quantity, 0);

  const r = await fetch('api/orders.php', {
    method:  'POST',
    headers: { 'Content-Type': 'application/json' },
    body:    JSON.stringify({
      items:        items.map(i => ({
        product_id: i.product_id,
        name:       i.name,
        price:      i.price,
        qty:        i.quantity
      })),
      subtotal,
      delivery_fee: 0,
      total:        subtotal,
      payment,
      type:         'pickup',
      notes
    })
  });
  const result = await r.json();
  if (result.success) {
    showToast(`Order ${result.order_number} placed! 🎉`);
    Cart.clearBadge();
    navigate('profile');
  } else {
    showToast(result.message || 'Failed to place order', 'error');
  }
}

/* ══════════════════════════════════════════════════════
   LOGIN PAGE
══════════════════════════════════════════════════════ */
function renderLogin() {
  document.getElementById('app').innerHTML = `
    <div style="min-height:82vh;display:flex;align-items:center;
                justify-content:center;padding:20px">
      <div class="card" style="width:100%;max-width:400px">
        <div style="text-align:center;margin-bottom:28px">
          <h2 style="color:var(--text);font-size:22px;font-weight:800;margin-bottom:4px">
            Welcome Back</h2>
          <p style="color:var(--sub);font-size:14px">Sign in to your Lagro Bistro account</p>
        </div>
        <div class="form-group">
          <label class="form-label">Email or Username</label>
          <input id="l-id" class="form-input" type="text"
                 placeholder="your@email.com or username" autocomplete="username">
        </div>
        <div class="form-group" style="margin-bottom:24px">
          <label class="form-label">Password</label>
          <input id="l-pw" class="form-input" type="password" placeholder="••••••••"
                 autocomplete="current-password"
                 onkeydown="if(event.key==='Enter')doLogin()">
        </div>
        <button class="btn-primary" onclick="doLogin()"
                style="width:100%;padding:13px;font-size:15px">Sign In</button>
        <p style="text-align:center;color:var(--sub);font-size:13px;margin-top:18px">
          No account?
          <span style="color:var(--accent);cursor:pointer;font-weight:700"
                onclick="navigate('signup')">Sign Up</span>
        </p>
      </div>
    </div>`;
}

async function doLogin() {
  const login    = document.getElementById('l-id').value.trim();
  const password = document.getElementById('l-pw').value;
  if (!login || !password) { showToast('Fill in all fields', 'error'); return; }

  const res  = await fetch('api/login.php', {
    method:  'POST',
    headers: { 'Content-Type': 'application/json' },
    body:    JSON.stringify({ login, password })
  });
  const data = await res.json();

  if (data.success) {
    currentUser = data.user;
    applyTheme(data.theme || 'dark');
    showToast(`Welcome back, ${data.user.full_name}!`);
    updateNav();
    Cart.updateBadge();
    navigate('home');
  } else {
    showToast(data.message || 'Invalid credentials', 'error');
  }
}

/* ══════════════════════════════════════════════════════
   SIGNUP PAGE
══════════════════════════════════════════════════════ */
function renderSignup() {
  document.getElementById('app').innerHTML = `
    <div style="min-height:82vh;display:flex;align-items:center;
                justify-content:center;padding:20px">
      <div class="card" style="width:100%;max-width:500px">
        <div style="text-align:center;margin-bottom:24px">
          <h2 style="color:var(--text);font-size:22px;font-weight:800;margin-bottom:4px">
            Create Account</h2>
          <p style="color:var(--sub);font-size:14px">Join Lagro Bistro today</p>
        </div>
        <div class="form-group">
          <label class="form-label">Full Name</label>
          <input id="s-name" class="form-input" type="text" placeholder="Juan dela Cruz">
        </div>
        <div class="form-group">
          <label class="form-label">Username</label>
          <input id="s-user" class="form-input" type="text" placeholder="juandelacruz">
        </div>
        <div class="form-group">
          <label class="form-label">Email</label>
          <input id="s-email" class="form-input" type="email" placeholder="juan@email.com">
        </div>
        <div class="form-group">
          <label class="form-label">Phone</label>
          <input id="s-phone" class="form-input" type="text" placeholder="09XX-XXX-XXXX">
        </div>
        <div class="form-group">
          <label class="form-label">LRN (Learner Reference Number)</label>
          <input id="s-lrn" class="form-input" type="text" placeholder="e.g., 123456789012">
        </div>
        <div class="form-group">
          <label class="form-label">Grade</label>
          <input id="s-grade" class="form-input" type="text" placeholder="e.g., Grade 10">
        </div>
        <div class="form-group">
          <label class="form-label">Section</label>
          <input id="s-section" class="form-input" type="text" placeholder="e.g., A, B, C">
        </div>
        <div class="form-group">
          <label class="form-label">Password</label>
          <input id="s-pw" class="form-input" type="password" placeholder="Min 8 characters">
        </div>
        <div class="form-group" style="margin-bottom:24px">
          <label class="form-label">Confirm Password</label>
          <input id="s-cpw" class="form-input" type="password" placeholder="Repeat password"
                 onkeydown="if(event.key==='Enter')doSignup()">
        </div>
        <button class="btn-primary" onclick="doSignup()"
                style="width:100%;padding:13px;font-size:15px">Create Account</button>
        <p style="text-align:center;color:var(--sub);font-size:13px;margin-top:18px">
          Already have an account?
          <span style="color:var(--accent);cursor:pointer;font-weight:700"
                onclick="navigate('login')">Sign In</span>
        </p>
      </div>
    </div>`;
}

async function doSignup() {
  const full_name = document.getElementById('s-name').value.trim();
  const username  = document.getElementById('s-user').value.trim();
  const email     = document.getElementById('s-email').value.trim();
  const phone     = document.getElementById('s-phone').value.trim();
  const lrn       = document.getElementById('s-lrn').value.trim();
  const grade     = document.getElementById('s-grade').value.trim();
  const section   = document.getElementById('s-section').value.trim();
  const password  = document.getElementById('s-pw').value;
  const confirm   = document.getElementById('s-cpw').value;

  if (!full_name || !username || !email || !password || !confirm) {
    showToast('All fields are required', 'error'); return;
  }
  if (password !== confirm) { showToast("Passwords don't match", 'error'); return; }
  if (password.length < 8)  { showToast('Password must be at least 8 characters', 'error'); return; }

  const res  = await fetch('api/signup.php', {
    method:  'POST',
    headers: { 'Content-Type': 'application/json' },
    body:    JSON.stringify({ full_name, username, email, phone, lrn, grade, section, password, confirm })
  });
  const data = await res.json();

  if (data.success) {
    currentUser = data.user;
    showToast('Account created! Welcome to Lagro Bistro! 🎉');
    updateNav();
    Cart.updateBadge();
    navigate('home');
  } else {
    showToast(data.message || 'Signup failed', 'error');
  }
}

/* ══════════════════════════════════════════════════════
   PROFILE PAGE
══════════════════════════════════════════════════════ */
async function renderProfile() {
  if (!currentUser) { navigate('login'); return; }
  const app = document.getElementById('app');
  app.innerHTML = `<div style="padding:60px;text-align:center;color:var(--sub)">Loading…</div>`;

  const res    = await fetch('api/orders.php');
  const orders = await res.json();

  app.innerHTML = `
    <div class="page-wrap" style="max-width:920px">
      <h2 style="font-size:26px;font-weight:800;color:var(--text);margin-bottom:28px">
        My Profile</h2>
      <div style="display:grid;grid-template-columns:280px 1fr;gap:24px;align-items:start">

        <!-- Sidebar -->
        <div class="card" style="text-align:center">
          <div style="width:80px;height:80px;border-radius:50%;
                      background:linear-gradient(135deg,var(--accent),var(--brown));
                      margin:0 auto 16px;display:flex;align-items:center;
                      justify-content:center;font-size:32px;color:#fff;font-weight:700">
            ${esc(currentUser.full_name[0].toUpperCase())}
          </div>
          <h3 style="color:var(--text);font-weight:700;font-size:17px;margin-bottom:4px">
            ${esc(currentUser.full_name)}</h3>
          <p style="color:var(--sub);font-size:13px;margin-bottom:10px">
            @${esc(currentUser.username)}</p>
          <span style="background:rgba(200,144,42,.2);color:var(--accent);font-size:11px;
                       font-weight:700;padding:4px 12px;border-radius:10px;
                       text-transform:uppercase">${esc(currentUser.role)}</span>
          <div style="margin-top:20px;padding-top:20px;border-top:1px solid var(--border);
                      text-align:left">
            <p style="color:var(--sub);font-size:12px;margin-bottom:3px">Email</p>
            <p style="color:var(--text);font-size:13px;margin-bottom:14px;word-break:break-all">
              ${esc(currentUser.email)}</p>
            <p style="color:var(--sub);font-size:12px;margin-bottom:3px">Total Orders</p>
            <p style="color:var(--accent);font-weight:800;font-size:24px">${orders.length}</p>
          </div>
        </div>

        <!-- Orders -->
        <div>
          <h3 style="color:var(--text);font-weight:700;font-size:17px;margin-bottom:16px">
            Order History</h3>
          ${orders.length === 0
            ? `<div class="card" style="text-align:center;padding:40px">
                 <div style="font-size:44px;margin-bottom:14px">📋</div>
                 <p style="color:var(--sub)">No orders yet.
                   <span style="color:var(--accent);cursor:pointer;font-weight:700"
                         onclick="navigate('menu')">Order now!</span></p>
               </div>`
            : orders.map(o => `
                <div class="card" style="margin-bottom:12px;padding:18px">
                  <div style="display:flex;justify-content:space-between;
                               align-items:flex-start;margin-bottom:10px">
                    <div>
                      <span style="color:var(--text);font-weight:700;font-size:14px">
                        ${esc(o.order_number)}</span>
                      <span style="color:var(--sub);font-size:12px;margin-left:10px">
                        ${(o.created_at || '').split(' ')[0]}</span>
                    </div>
                    <span class="status-badge ${statusClass(o.status)}">${o.status}</span>
                  </div>
                  <p style="font-size:13px;color:var(--sub);margin-bottom:8px">
                    ${(o.items || []).map(i =>
                      `${esc(i.product_name)} ×${i.quantity}`).join(' · ')}
                  </p>
                  <div style="display:flex;justify-content:space-between;align-items:center">
                    <span style="color:var(--sub);font-size:12px;text-transform:capitalize">
                      ${(o.payment_method || '').replace('_', ' ')} · Pickup</span>
                    <span style="color:var(--accent);font-weight:700">
                      ₱${parseFloat(o.total_amount).toFixed(2)}</span>
                  </div>
                  ${o.customer_notes
                    ? `<p style="font-size:12px;color:var(--sub);margin-top:8px;font-style:italic">
                         📝 "${esc(o.customer_notes)}"</p>` : ''}
                </div>`).join('')}
        </div>
      </div>
    </div>`;
}

/* ══════════════════════════════════════════════════════
   ADMIN — ORDERS
══════════════════════════════════════════════════════ */
async function renderAdmin() {
  if (!currentUser || currentUser.role !== 'admin') { navigate('home'); return; }
  document.getElementById('app').innerHTML =
    `<div style="padding:60px;text-align:center;color:var(--sub)">Loading orders…</div>`;
  const res = await fetch('api/orders.php?all=1');
  window._adminOrders = await res.json();
  window._adminFilter = 'all';
  _renderAdminTable();
}

function _renderAdminTable() {
  const orders   = window._adminOrders || [];
  const filter   = window._adminFilter || 'all';
  const filtered = filter === 'all' ? orders : orders.filter(o => o.status === filter);
  const statuses = ['pending','confirmed','preparing','ready','completed','cancelled'];
  const counts   = {};
  statuses.forEach(s => counts[s] = orders.filter(o => o.status === s).length);

  document.getElementById('app').innerHTML = `
    <div class="page-wrap" style="max-width:1100px">
      <h2 style="font-size:26px;font-weight:800;color:var(--text);margin-bottom:6px">
        Admin Panel</h2>
      <p style="color:var(--sub);margin-bottom:28px">Manage all customer orders</p>

      <!-- Stats row -->
      <div style="display:grid;grid-template-columns:repeat(6,1fr);gap:12px;margin-bottom:28px">
        ${statuses.map(s => `
          <div class="card" style="text-align:center;padding:14px">
            <div style="font-size:20px;font-weight:800" class="${statusClass(s)}">
              ${counts[s]}
            </div>
            <div style="font-size:10px;color:var(--sub);text-transform:capitalize;margin-top:4px">
              ${s}
            </div>
          </div>`).join('')}
      </div>

      <!-- Filter pills -->
      <div style="display:flex;gap:8px;margin-bottom:20px;flex-wrap:wrap">
        ${['all', ...statuses].map(f =>
          `<button class="filter-btn${filter === f ? ' active' : ''}"
                   onclick="setAdminFilter('${f}')">${f}</button>`
        ).join('')}
      </div>

      <!-- Orders list -->
      <div id="orders-list">
        ${filtered.length === 0
          ? `<div class="card" style="text-align:center;padding:40px;color:var(--sub)">
               No orders for this filter.</div>`
          : filtered.map(o => `
              <div class="card" style="margin-bottom:12px;padding:18px">
                <div style="display:flex;justify-content:space-between;
                             align-items:flex-start;margin-bottom:10px">
                  <div>
                    <span style="color:var(--text);font-weight:700">
                      ${esc(o.order_number)}</span>
                    <span style="color:var(--sub);font-size:12px;margin-left:10px">
                      ${(o.created_at || '').split(' ')[0]}</span>
                    <span style="color:var(--sub);font-size:12px;margin-left:8px">
                      — ${esc(o.customer_name || 'Unknown')}</span>
                  </div>
                  <div style="display:flex;gap:10px;align-items:center">
                    <span class="status-badge ${statusClass(o.status)}">${o.status}</span>
                    <span style="color:var(--accent);font-weight:700">
                      ₱${parseFloat(o.total_amount).toFixed(2)}</span>
                  </div>
                </div>
                <p style="font-size:13px;color:var(--sub);margin-bottom:8px">
                  ${(o.items || []).map(i =>
                    `${esc(i.product_name)} ×${i.quantity}`).join(' · ')}
                </p>
                ${o.customer_notes
                  ? `<p style="font-size:12px;color:var(--sub);margin-bottom:8px;font-style:italic">
                       📝 "${esc(o.customer_notes)}"</p>` : ''}
                <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:10px">
                  <button class="action-btn ab-blue" onclick="viewOrderModal(${o.id})">
                    👁 View
                  </button>
                  ${o.status === 'pending'
                    ? `<button class="action-btn ab-blue"
                               onclick="adminStatus(${o.id},'confirmed')">
                         <img src="${ICONS.check}" alt=""> Confirm
                       </button>` : ''}
                  ${o.status === 'confirmed'
                    ? `<button class="action-btn ab-orange"
                               onclick="adminStatus(${o.id},'preparing')">🍳 Preparing</button>` : ''}
                  ${o.status === 'preparing'
                    ? `<button class="action-btn ab-purple"
                               onclick="adminStatus(${o.id},'ready')">
                         <img src="${ICONS.check}" alt=""> Ready
                       </button>` : ''}
                  ${o.status === 'ready'
                    ? `<button class="action-btn ab-teal"
                               onclick="adminStatus(${o.id},'completed')">🎉 Complete</button>` : ''}
                  ${!['completed','cancelled'].includes(o.status)
                    ? `<button class="action-btn ab-red"
                               onclick="adminStatus(${o.id},'cancelled')">
                         <img src="${ICONS.close}" alt="" style="filter:invert(50%) sepia(80%) saturate(600%) hue-rotate(310deg)"> Cancel
                       </button>` : ''}
                </div>
              </div>`).join('')}
      </div>
    </div>`;
}

function setAdminFilter(f) { window._adminFilter = f; _renderAdminTable(); }

async function adminStatus(id, status) {
  const o   = (window._adminOrders || []).find(x => x.id === id);
  const res = await fetch('api/orders.php', {
    method:  'PATCH',
    headers: { 'Content-Type': 'application/json' },
    body:    JSON.stringify({ id, status, admin_notes: o?.admin_notes || '' })
  });
  const data = await res.json();
  if (data.success) {
    window._adminOrders = window._adminOrders.map(x => x.id === id ? {...x, status} : x);
    showToast(`Order updated → ${status}`);
    _renderAdminTable();
  } else showToast(data.message || 'Update failed', 'error');
}

function viewOrderModal(id) {
  const o = (window._adminOrders || []).find(x => x.id === id);
  if (!o) return;
  openModal(`
    <div class="modal-header">
      <h3 style="color:var(--text);font-weight:700;font-size:17px">${esc(o.order_number)}</h3>
      <button class="modal-close" onclick="closeModal()">
        <img src="${ICONS.close}" alt="Close">
      </button>
    </div>
    <p style="color:var(--sub);font-size:13px;margin-bottom:20px">
      ${esc(o.customer_name || 'Unknown')} ·
      ${(o.created_at || '').split(' ')[0]} ·
      <span class="status-badge ${statusClass(o.status)}">${o.status}</span>
    </p>

    <p style="color:var(--sub);font-size:11px;font-weight:700;text-transform:uppercase;
              letter-spacing:.5px;margin-bottom:8px">Items</p>
    ${(o.items || []).map(i => `
      <div style="display:flex;justify-content:space-between;padding:8px 0;
                  border-bottom:1px solid var(--border)">
        <span style="color:var(--text);font-size:13px">
          ${esc(i.product_name)} ×${i.quantity}</span>
        <span style="color:var(--accent);font-weight:600;font-size:13px">
          ₱${(parseFloat(i.product_price) * i.quantity).toFixed(2)}</span>
      </div>`).join('')}
    <div style="display:flex;justify-content:space-between;padding:12px 0;margin-bottom:16px">
      <span style="color:var(--text);font-weight:700">Total</span>
      <span style="color:var(--accent);font-weight:800;font-size:18px">
        ₱${parseFloat(o.total_amount).toFixed(2)}</span>
    </div>

    <div class="form-group">
      <label class="form-label">Customer Notes</label>
      <p style="color:var(--text);font-size:14px">${esc(o.customer_notes || 'None')}</p>
    </div>
    <div class="form-group">
      <label class="form-label">Payment Method</label>
      <p style="color:var(--text);font-size:14px;text-transform:capitalize">
        ${(o.payment_method || '').replace('_', ' ')} · Pickup</p>
    </div>
    <div class="form-group">
      <label class="form-label">Admin Notes / Customization</label>
      <textarea id="a-notes" class="form-input" style="min-height:80px;resize:vertical"
                placeholder="Add notes or customizations…">${esc(o.admin_notes || '')}</textarea>
    </div>
    <div style="display:flex;gap:8px">
      <button class="btn-primary" onclick="saveAdminNotes(${o.id})"
              style="flex:1;padding:11px">
        <img src="${ICONS.check}" alt="" style="width:14px;vertical-align:middle;margin-right:4px">
        Save Notes
      </button>
      <button class="btn-outline" onclick="closeModal()" style="flex:1;padding:11px">
        Close
      </button>
    </div>`);
}

async function saveAdminNotes(id) {
  const notes = document.getElementById('a-notes').value;
  const o     = (window._adminOrders || []).find(x => x.id === id);
  await fetch('api/orders.php', {
    method:  'PATCH',
    headers: { 'Content-Type': 'application/json' },
    body:    JSON.stringify({ id, status: o.status, admin_notes: notes })
  });
  window._adminOrders = window._adminOrders.map(x => x.id === id ? {...x, admin_notes: notes} : x);
  showToast('Notes saved!');
  closeModal();
}

/* ══════════════════════════════════════════════════════
   STOCKS PAGE
══════════════════════════════════════════════════════ */
async function renderStocks() {
  if (!currentUser || currentUser.role !== 'admin') { navigate('home'); return; }
  document.getElementById('app').innerHTML =
    `<div style="padding:60px;text-align:center;color:var(--sub)">Loading…</div>`;
  await loadProducts();
  const catRes     = await fetch('api/categories.php');
  window._cats     = await catRes.json();
  _renderStocksPage();
}

function _renderStocksPage() {
  document.getElementById('app').innerHTML = `
    <div class="page-wrap" style="max-width:1100px">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:28px">
        <div>
          <h2 style="font-size:26px;font-weight:800;color:var(--text);margin-bottom:4px">
            Stock Management</h2>
          <p style="color:var(--sub)">Manage your product inventory</p>
        </div>
        <button class="btn-primary" onclick="showProductForm(null)"
                style="padding:11px 22px">+ Add Product</button>
      </div>
      <div id="stock-form-wrap"></div>
      <div class="products-grid">
        ${allProducts.map(p => stockCardHTML(p)).join('')}
      </div>
    </div>`;
}

function stockCardHTML(p) {
  const qty = parseInt(p.stock_quantity);
  return `
    <div class="card" style="padding:16px">
      <div style="display:flex;gap:12px;align-items:flex-start;margin-bottom:12px">
        <div style="width:58px;height:58px;border-radius:10px;overflow:hidden;flex-shrink:0;
                    background:linear-gradient(135deg,#2a1a0a,#1a0d05);
                    display:flex;align-items:center;justify-content:center">
          ${p.image_path
            ? `<img src="${esc(p.image_path)}" style="width:100%;height:100%;object-fit:cover">`
            : '<span style="font-size:26px">🍽️</span>'}
        </div>
        <div style="flex:1;min-width:0">
          <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:4px">
            <p style="font-weight:700;color:var(--text);font-size:14px;
                      white-space:nowrap;overflow:hidden;text-overflow:ellipsis">
              ${esc(p.name)}</p>
            <div style="display:flex;gap:3px;flex-shrink:0">
              ${p.is_best_seller == 1
                ? `<span style="background:rgba(200,144,42,.2);color:var(--accent);font-size:9px;
                               font-weight:700;padding:2px 6px;border-radius:6px;
                               display:flex;align-items:center;gap:3px">
                     <img src="${ICONS.star}" style="width:10px;height:10px"> BEST
                   </span>` : ''}
              ${p.is_available != 1
                ? `<span style="background:rgba(208,2,27,.15);color:#ff4455;font-size:9px;
                               font-weight:700;padding:2px 6px;border-radius:6px">OFF</span>` : ''}
            </div>
          </div>
          <p style="color:var(--sub);font-size:11px;margin-bottom:6px">
            ${esc(p.category_name || '')}</p>
          <div style="display:flex;justify-content:space-between;align-items:center">
            <span style="color:var(--accent);font-weight:700;font-size:16px">
              ₱${parseFloat(p.price).toFixed(2)}</span>
            <span style="font-size:12px;font-weight:600;
                         color:${qty < 10 ? '#ff4455' : qty < 30 ? '#f5a623' : 'var(--sub)'}">
              Stock: ${qty}
            </span>
          </div>
        </div>
      </div>
      <div style="display:flex;gap:8px">
        <button class="action-btn ab-blue" onclick="showProductForm(${p.id})"
                style="flex:1;padding:8px">✏️ Edit</button>
        <button class="action-btn ab-red"  onclick="deleteProduct(${p.id})"
                style="flex:1;padding:8px">
          <img src="${ICONS.close}" alt="" style="filter:invert(50%) sepia(80%) saturate(600%) hue-rotate(310deg)">
          Delete
        </button>
      </div>
    </div>`;
}

function showProductForm(editId) {
  const p    = editId ? allProducts.find(x => x.id === editId) : null;
  const cats = window._cats || [];
  document.getElementById('stock-form-wrap').innerHTML = `
    <div class="card" style="margin-bottom:24px;border-color:var(--accent)">
      <div class="modal-header" style="margin-bottom:18px">
        <h3 style="color:var(--text);font-weight:700">
          ${p ? 'Edit Product' : 'Add New Product'}</h3>
        <button class="modal-close" onclick="cancelProductForm()">
          <img src="${ICONS.close}" alt="Cancel">
        </button>
      </div>
      <form id="pf" onsubmit="submitProduct(event,${editId || 'null'})"
            enctype="multipart/form-data">
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px">
          <div class="form-group">
            <label class="form-label">Product Name</label>
            <input name="name" class="form-input" required
                   value="${p ? esc(p.name) : ''}" placeholder="Product name">
          </div>
          <div class="form-group">
            <label class="form-label">Category</label>
            <select name="category_id" class="form-input">
              ${cats.map(c =>
                `<option value="${c.id}"${p && c.id == p.category_id ? ' selected' : ''}>
                  ${esc(c.name)}</option>`).join('')}
            </select>
          </div>
          <div class="form-group">
            <label class="form-label">Price (₱)</label>
            <input name="price" class="form-input" type="number" step="0.01"
                   min="0" required value="${p ? p.price : ''}" placeholder="0.00">
          </div>
          <div class="form-group">
            <label class="form-label">Stock Quantity</label>
            <input name="stock_quantity" class="form-input" type="number"
                   min="0" required value="${p ? p.stock_quantity : ''}" placeholder="0">
          </div>
          <div class="form-group" style="grid-column:1/-1">
            <label class="form-label">Description</label>
            <input name="description" class="form-input"
                   value="${p ? esc(p.description || '') : ''}"
                   placeholder="Short description">
          </div>
          <div class="form-group" style="grid-column:1/-1">
            <label class="form-label">Product Image</label>
            <input name="image" class="form-input" type="file"
                   accept="image/*" style="padding:8px">
            ${p && p.image_path
              ? `<p style="color:var(--sub);font-size:11px;margin-top:4px">
                   Current: ${esc(p.image_path)} — upload new to replace</p>` : ''}
          </div>
          <div class="form-group" style="display:flex;gap:24px;align-items:center;
                                          grid-column:1/-1">
            <label style="display:flex;align-items:center;gap:8px;cursor:pointer;
                           color:var(--text);font-size:13px">
              <input type="checkbox" name="is_best_seller" value="1"
                     ${p && p.is_best_seller == 1 ? 'checked' : ''}
                     style="accent-color:var(--accent)">
              <img src="${ICONS.star}" style="width:14px;height:14px"> Best Seller
            </label>
            <label style="display:flex;align-items:center;gap:8px;cursor:pointer;
                           color:var(--text);font-size:13px">
              <input type="checkbox" name="is_available" value="1"
                     ${!p || p.is_available == 1 ? 'checked' : ''}
                     style="accent-color:var(--accent)">
              <img src="${ICONS.check}" style="width:14px;height:14px"> Available
            </label>
          </div>
        </div>
        <div style="display:flex;gap:10px;margin-top:4px">
          <button type="submit" class="btn-primary">
            <img src="${ICONS.check}" alt="" style="width:14px;vertical-align:middle;margin-right:4px">
            ${p ? 'Update Product' : 'Add Product'}
          </button>
          <button type="button" class="btn-outline" onclick="cancelProductForm()">Cancel</button>
        </div>
      </form>
    </div>`;
  document.getElementById('stock-form-wrap').scrollIntoView({ behavior: 'smooth' });
}

function cancelProductForm() {
  document.getElementById('stock-form-wrap').innerHTML = '';
}

async function submitProduct(e, editId) {
  e.preventDefault();
  const fd = new FormData(document.getElementById('pf'));
  fd.set('is_best_seller', fd.get('is_best_seller') ? '1' : '0');
  fd.set('is_available',   fd.get('is_available')   ? '1' : '0');
  if (editId) fd.append('_method', 'PUT');

  const url = editId ? `api/products.php?id=${editId}` : 'api/products.php';
  const res  = await fetch(url, { method: 'POST', body: fd });
  const data = await res.json();

  if (data.success) {
    showToast(editId ? 'Product updated!' : 'Product added!');
    await loadProducts();
    _renderStocksPage();
  } else showToast(data.message || 'Error saving product', 'error');
}

async function deleteProduct(id) {
  if (!confirm('Delete this product? This cannot be undone.')) return;
  const res  = await fetch('api/products.php', {
    method:  'DELETE',
    headers: { 'Content-Type': 'application/json' },
    body:    JSON.stringify({ id })
  });
  const data = await res.json();
  if (data.success) {
    showToast('Product deleted');
    await loadProducts();
    _renderStocksPage();
  } else showToast(data.message || 'Cannot delete product', 'error');
}

/* ══════════════════════════════════════════════════════
   MODERATOR PAGE
══════════════════════════════════════════════════════ */
async function renderModerator() {
  if (!currentUser || !['moderator','admin'].includes(currentUser.role)) {
    navigate('home'); return;
  }
  document.getElementById('app').innerHTML =
    `<div style="padding:60px;text-align:center;color:var(--sub)">Loading…</div>`;
  const res = await fetch('api/users.php');
  window._modUsers = await res.json();
  _renderModTable();
}

function _renderModTable() {
  const users = window._modUsers || [];
  const rc    = { customer: 'var(--sub)', moderator: '#4a90e2', admin: 'var(--accent)' };
  const cnt   = { customer: 0, moderator: 0, admin: 0 };
  users.forEach(u => { if (cnt[u.role] !== undefined) cnt[u.role]++; });

  document.getElementById('app').innerHTML = `
    <div class="page-wrap" style="max-width:1000px">
      <h2 style="font-size:26px;font-weight:800;color:var(--text);margin-bottom:6px">
        Moderator Panel</h2>
      <p style="color:var(--sub);margin-bottom:28px">Manage users and permissions</p>

      <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:14px;margin-bottom:28px">
        ${['customer','moderator','admin'].map(r => `
          <div class="card" style="text-align:center;padding:16px">
            <div style="font-size:22px;font-weight:800;color:${rc[r]}">${cnt[r]}</div>
            <div style="font-size:11px;color:var(--sub);text-transform:capitalize;margin-top:4px">
              ${r}s</div>
          </div>`).join('')}
      </div>

      <div class="card" style="padding:0;overflow:hidden">
        <div style="padding:14px 20px;border-bottom:1px solid var(--border);
                    display:grid;grid-template-columns:1fr 120px 80px 1fr;gap:12px">
          ${['User','Role','Status','Actions'].map(h =>
            `<span style="color:var(--sub);font-size:11px;font-weight:700;
                          text-transform:uppercase">${h}</span>`).join('')}
        </div>
        ${users.map(u => `
          <div style="padding:13px 20px;border-bottom:1px solid var(--border);
                      display:grid;grid-template-columns:1fr 120px 80px 1fr;
                      gap:12px;align-items:center">
            <div>
              <span style="color:var(--text);font-weight:600;font-size:14px">
                ${esc(u.full_name)}</span>
              <span style="color:var(--sub);font-size:12px;margin-left:6px">
                @${esc(u.username)}</span>
            </div>
            <span style="color:${rc[u.role] || 'var(--sub)'};font-size:12px;
                         font-weight:700;text-transform:capitalize">${u.role}</span>
            <span style="font-size:12px;font-weight:700;
                         color:${u.is_banned ? '#ff4455' : '#5aad00'}">
              ${u.is_banned ? 'Banned' : 'Active'}</span>
            <div style="display:flex;gap:6px;flex-wrap:wrap">
              ${u.id == currentUser.id
                ? `<span style="color:var(--sub);font-size:12px">You</span>`
                : `<button class="action-btn ab-blue"
                          onclick="showRoleModal(${u.id},'${esc(u.full_name)}','${u.role}')">
                     Change Role</button>
                   ${u.is_banned
                     ? `<button class="action-btn ab-teal"
                               onclick="modUnban(${u.id},'${esc(u.full_name)}')">
                          <img src="${ICONS.check}" alt=""> Unban</button>`
                     : `<button class="action-btn ab-red"
                               onclick="showBanModal(${u.id},'${esc(u.full_name)}')">
                          <img src="${ICONS.close}" alt=""
                               style="filter:invert(50%) sepia(80%) saturate(600%) hue-rotate(310deg)">
                          Ban</button>`}`}
            </div>
          </div>`).join('')}
      </div>
    </div>`;
}

function showBanModal(id, name) {
  openModal(`
    <div class="modal-header">
      <h3 style="color:#ff4455;font-weight:700;font-size:18px">⛔ Ban User</h3>
      <button class="modal-close" onclick="closeModal()">
        <img src="${ICONS.close}" alt="Close">
      </button>
    </div>
    <p style="color:var(--sub);font-size:14px;margin-bottom:20px">
      You are about to ban <strong style="color:var(--text)">${esc(name)}</strong>.
      They will no longer be able to log in.
    </p>
    <div class="form-group">
      <label class="form-label">Ban Reason</label>
      <textarea id="ban-reason" class="form-input" style="min-height:80px;resize:vertical"
                placeholder="Reason for ban…"></textarea>
    </div>
    <div style="display:flex;gap:8px;margin-top:8px">
      <button onclick="modBan(${id},'${esc(name)}')"
              style="flex:1;background:linear-gradient(135deg,#9a0015,#6a0010);
                     border:none;border-radius:8px;padding:11px;color:#fff;
                     cursor:pointer;font-weight:700;font-size:13px;font-family:inherit;
                     display:flex;align-items:center;justify-content:center;gap:6px">
        <img src="${ICONS.close}" alt="" style="width:14px;filter:none"> Confirm Ban
      </button>
      <button class="btn-outline" onclick="closeModal()" style="flex:1;padding:11px">Cancel</button>
    </div>`);
}

async function modBan(id, name) {
  const reason = document.getElementById('ban-reason').value.trim();
  const res    = await fetch('api/users.php', {
    method:  'PATCH',
    headers: { 'Content-Type': 'application/json' },
    body:    JSON.stringify({ user_id: id, ban: true, reason })
  });
  const data = await res.json();
  if (data.success) {
    showToast(`${name} has been banned`, 'error');
    window._modUsers = window._modUsers.map(u => u.id == id
      ? {...u, is_banned: 1, ban_reason: reason} : u);
    closeModal();
    _renderModTable();
  } else showToast(data.message || 'Error', 'error');
}

async function modUnban(id, name) {
  const res  = await fetch('api/users.php', {
    method:  'PATCH',
    headers: { 'Content-Type': 'application/json' },
    body:    JSON.stringify({ user_id: id, ban: false })
  });
  const data = await res.json();
  if (data.success) {
    showToast(`${name} has been unbanned`);
    window._modUsers = window._modUsers.map(u =>
      u.id == id ? {...u, is_banned: 0} : u);
    _renderModTable();
  } else showToast(data.message || 'Error', 'error');
}

function showRoleModal(id, name, current) {
  const roles = [
    ['customer',  '👤 Customer'],
    ['moderator', '🛡 Moderator'],
    ['admin',     '👑 Admin'],
  ];
  openModal(`
    <div class="modal-header">
      <h3 style="color:var(--text);font-weight:700;font-size:18px">Change Role</h3>
      <button class="modal-close" onclick="closeModal()">
        <img src="${ICONS.close}" alt="Close">
      </button>
    </div>
    <p style="color:var(--sub);font-size:14px;margin-bottom:20px">
      Assign a new role to <strong style="color:var(--text)">${esc(name)}</strong>
    </p>
    <div style="display:flex;flex-direction:column;gap:10px;margin-bottom:20px">
      ${roles.map(([r, lbl]) => `
        <button onclick="modChangeRole(${id},'${r}','${esc(name)}')"
                style="background:${current === r ? 'rgba(200,144,42,.2)' : 'transparent'};
                       border:1px solid ${current === r ? 'var(--accent)' : 'var(--border)'};
                       border-radius:8px;padding:12px 16px;
                       color:${current === r ? 'var(--accent)' : 'var(--text)'};
                       cursor:pointer;font-size:14px;font-weight:${current === r ? 700 : 400};
                       text-align:left;font-family:inherit;
                       display:flex;align-items:center;justify-content:space-between">
          <span>${lbl}${current === r
            ? ' <span style="opacity:.55;font-size:12px">(current)</span>' : ''}</span>
          ${current === r
            ? `<img src="${ICONS.check}" style="width:14px;height:14px">` : ''}
        </button>`).join('')}
    </div>
    <button class="btn-outline" onclick="closeModal()" style="width:100%;padding:11px">
      Cancel
    </button>`);
}

async function modChangeRole(id, role, name) {
  const res  = await fetch('api/users.php', {
    method:  'PATCH',
    headers: { 'Content-Type': 'application/json' },
    body:    JSON.stringify({ user_id: id, role })
  });
  const data = await res.json();
  if (data.success) {
    showToast(`${name}'s role → ${role}`);
    window._modUsers = window._modUsers.map(u => u.id == id ? {...u, role} : u);
    closeModal();
    _renderModTable();
  } else showToast(data.message || 'Error', 'error');
}
