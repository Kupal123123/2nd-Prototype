# 🍽️ Lagro Bistro — Setup Guide

## Folder Structure
```
lagro-bistro/
├── index.html              ← Main app (open this in browser)
├── generate_hash.php       ← Run ONCE to create admin account, then delete!
├── DATABASE_SETUP.sql      ← Run in phpMyAdmin SQL tab
├── css/
│   └── style.css
├── js/
│   ├── app.js
│   └── cart.js
├── api/
│   ├── session.php
│   ├── login.php
│   ├── signup.php
│   ├── cart.php
│   ├── orders.php
│   ├── products.php
│   ├── users.php
│   └── categories.php
├── includes/
│   ├── db.php              ← Edit your DB credentials here
│   └── session.php
├── icons/                  ← All SVG icons (included)
└── uploads/
    └── products/           ← Product images go here (auto-created)
```

---

## Step-by-Step Setup

### 1. Place files in your web server
- **XAMPP** → Copy `lagro-bistro/` to `C:/xampp/htdocs/lagro-bistro/`
- **WAMP**  → Copy `lagro-bistro/` to `C:/wamp64/www/lagro-bistro/`

### 2. Run the database SQL
1. Open phpMyAdmin → `http://localhost/phpmyadmin`
2. Click the **SQL** tab at the top
3. Open `DATABASE_SETUP.sql`, copy everything, paste into SQL tab
4. Click **Go**

### 3. Create the admin account (fixes the bcrypt hash error)
1. Visit `http://localhost/lagro-bistro/generate_hash.php`
2. Copy the two INSERT statements shown on the page
3. Go back to phpMyAdmin → SQL tab → paste and run them
4. **Delete `generate_hash.php` after!** (security)

### 4. Edit database config if needed
Open `includes/db.php` and update:
```php
define('DB_USER', 'root');   // your MySQL username
define('DB_PASS', '');       // your MySQL password (blank for XAMPP default)
```

### 5. Open the site
Visit: `http://localhost/lagro-bistro/`

---

## Default Accounts (after running generate_hash.php)

| Role      | Username    | Password    |
|-----------|-------------|-------------|
| Admin     | `admin`     | `Admin@1234`|
| Moderator | `moderator` | `Mod@1234`  |

---

## Features

| Feature | How to Access |
|---------|---------------|
| Home + Best Sellers | `/` — visible to everyone |
| Menu | Click **Menu** in navbar |
| Cart + Checkout | 🛒 icon — must be logged in |
| Order History | Profile dropdown → My Profile |
| Admin Orders Panel | **Orders** tab — admin only |
| Stock Management | **Stocks** tab — admin only |
| User Moderator Panel | **Moderator** tab — admin + moderator |
| Light/Dark Mode | Moon/Sun icon in navbar |

---

## Roles

| Role | Permissions |
|------|-------------|
| `customer` | Browse, add to cart, order, view own orders |
| `moderator` | All customer permissions + ban users + change roles |
| `admin` | All moderator permissions + manage orders + manage products/stocks |

---

## Troubleshooting

**Blank page / errors?**
- Make sure PHP 7.4+ is running (XAMPP Control Panel → Apache)
- Check `includes/db.php` credentials

**"Database connection failed"?**
- Start MySQL in XAMPP Control Panel
- Verify DB name is `lagro_bistro`

**Images not uploading?**
- The `uploads/products/` folder is auto-created on first upload
- If it fails, create it manually and set permissions to 755

**Cart badge not updating?**
- You must be logged in for the cart to work
- Make sure PHP sessions are working (default XAMPP config is fine)
