-- ============================================================
-- LAGRO BISTRO - Complete Database Setup
-- ============================================================
-- HOW TO USE:
--   1. Open phpMyAdmin  →  http://localhost/phpmyadmin
--   2. Click the "SQL" tab
--   3. Paste this ENTIRE file and click "Go"
--   4. Then visit http://localhost/lagro-bistro/generate_hash.php
--      to get the INSERT for the admin account with a real hash
-- ============================================================

CREATE DATABASE IF NOT EXISTS lagro_bistro
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE lagro_bistro;

-- ─────────────────────────────────────────────────────────────
-- TABLE: users
-- ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS users (
  id               INT           NOT NULL AUTO_INCREMENT,
  username         VARCHAR(50)   NOT NULL,
  email            VARCHAR(100)  NOT NULL,
  password         VARCHAR(255)  NOT NULL,
  full_name        VARCHAR(100)  NOT NULL,
  phone            VARCHAR(20)       NULL DEFAULT NULL,
  lrn              VARCHAR(20)       NULL DEFAULT NULL,
  grade            VARCHAR(20)       NULL DEFAULT NULL,
  section          VARCHAR(50)       NULL DEFAULT NULL,
  role             ENUM('customer','moderator','admin','owner')
                                 NOT NULL DEFAULT 'customer',
  is_banned        TINYINT(1)    NOT NULL DEFAULT 0,
  ban_reason       VARCHAR(255)      NULL DEFAULT NULL,
  theme_preference ENUM('dark','light')
                                 NOT NULL DEFAULT 'dark',
  created_at       TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at       TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP
                                          ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_username (username),
  UNIQUE KEY uq_email    (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ─────────────────────────────────────────────────────────────
-- TABLE: categories
-- ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS categories (
  id         INT          NOT NULL AUTO_INCREMENT,
  name       VARCHAR(100) NOT NULL,
  sort_order INT          NOT NULL DEFAULT 0,
  created_at TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ─────────────────────────────────────────────────────────────
-- TABLE: products
-- ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS products (
  id             INT            NOT NULL AUTO_INCREMENT,
  category_id    INT                NULL DEFAULT NULL,
  name           VARCHAR(150)   NOT NULL,
  description    TEXT               NULL DEFAULT NULL,
  price          DECIMAL(10,2)  NOT NULL,
  image_path     VARCHAR(255)       NULL DEFAULT NULL,
  stock_quantity INT            NOT NULL DEFAULT 0,
  is_best_seller TINYINT(1)     NOT NULL DEFAULT 0,
  is_available   TINYINT(1)     NOT NULL DEFAULT 1,
  sort_order     INT            NOT NULL DEFAULT 0,
  created_at     TIMESTAMP      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at     TIMESTAMP      NOT NULL DEFAULT CURRENT_TIMESTAMP
                                         ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  CONSTRAINT fk_product_category
    FOREIGN KEY (category_id) REFERENCES categories(id)
    ON DELETE SET NULL
    ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ─────────────────────────────────────────────────────────────
-- TABLE: cart
-- ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS cart (
  id            INT       NOT NULL AUTO_INCREMENT,
  user_id       INT       NOT NULL,
  product_id    INT       NOT NULL,
  quantity      INT       NOT NULL DEFAULT 1,
  customization TEXT          NULL DEFAULT NULL,
  added_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_cart_user_product (user_id, product_id),
  CONSTRAINT fk_cart_user
    FOREIGN KEY (user_id)    REFERENCES users(id)    ON DELETE CASCADE,
  CONSTRAINT fk_cart_product
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ─────────────────────────────────────────────────────────────
-- TABLE: orders
-- ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS orders (
  id               INT           NOT NULL AUTO_INCREMENT,
  order_number     VARCHAR(30)   NOT NULL,
  user_id          INT           NOT NULL,
  subtotal         DECIMAL(10,2) NOT NULL,
  delivery_fee     DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  total_amount     DECIMAL(10,2) NOT NULL,
  payment_method   ENUM('cash','gcash','credit_card','debit_card')
                                 NOT NULL DEFAULT 'cash',
  order_type       ENUM('pickup','delivery')
                                 NOT NULL DEFAULT 'pickup',
  delivery_address TEXT              NULL DEFAULT NULL,
  customer_notes   TEXT              NULL DEFAULT NULL,
  admin_notes      TEXT              NULL DEFAULT NULL,
  status           ENUM('pending','confirmed','preparing','ready','completed','cancelled')
                                 NOT NULL DEFAULT 'pending',
  created_at       TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at       TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP
                                          ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_order_number (order_number),
  CONSTRAINT fk_order_user
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ─────────────────────────────────────────────────────────────
-- TABLE: order_items
-- ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS order_items (
  id            INT           NOT NULL AUTO_INCREMENT,
  order_id      INT           NOT NULL,
  product_id    INT           NOT NULL,
  product_name  VARCHAR(150)  NOT NULL,
  product_price DECIMAL(10,2) NOT NULL,
  quantity      INT           NOT NULL,
  subtotal      DECIMAL(10,2) NOT NULL,
  customization TEXT              NULL DEFAULT NULL,
  PRIMARY KEY (id),
  CONSTRAINT fk_item_order
    FOREIGN KEY (order_id)   REFERENCES orders(id)   ON DELETE CASCADE,
  CONSTRAINT fk_item_product
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ─────────────────────────────────────────────────────────────
-- TABLE: ban_log
-- ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS ban_log (
  id           INT       NOT NULL AUTO_INCREMENT,
  user_id      INT       NOT NULL,
  action       ENUM('ban','unban') NOT NULL,
  reason       VARCHAR(255)    NULL DEFAULT NULL,
  performed_by INT       NOT NULL,
  created_at   TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  CONSTRAINT fk_banlog_user
    FOREIGN KEY (user_id)      REFERENCES users(id) ON DELETE CASCADE,
  CONSTRAINT fk_banlog_actor
    FOREIGN KEY (performed_by) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- SEED: Categories
-- ============================================================
INSERT INTO categories (name, sort_order) VALUES
  ('Coffee',       1),
  ('Non-Coffee',   2),
  ('Pastries',     3);

-- ============================================================
-- SEED: Sample products (no admin user yet — see below)
-- ============================================================
INSERT INTO products
  (category_id, name, description, price, stock_quantity, is_best_seller, is_available, sort_order)
VALUES
  (1, 'Iced Coffee',          'Classic iced coffee with fresh milk',                 85.00, 100, 1, 1, 1),
  (1, 'Caramel Macchiato',    'Espresso with velvety caramel and steamed milk',     110.00,  60, 1, 1, 2),
  (1, 'Matcha Latte',         'Premium matcha with steamed milk',                    95.00,  50, 0, 1, 3),
  (2, 'Strawberry Milk Tea',  'Creamy milk tea with strawberry and tapioca pearls',  95.00,  80, 1, 1, 1),
  (2, 'Silog Meal',           'Sinangag, itlog, and your choice of meat',           120.00,  30, 0, 1, 2),
  (2, 'Club Sandwich',        'Triple-decker sandwich with fries',                  145.00,  20, 0, 1, 3),
  (3, 'Cheese Muffin',        'Soft fluffy muffin topped with melted cheese',        65.00,  50, 1, 1, 1),
  (3, 'Ensaymada',            'Classic Filipino sweet bread with cheese topping',    55.00,  40, 0, 1, 2),
  (3, 'Pandesal',             'Traditional Filipino bread rolls, freshly baked',     15.00, 200, 0, 1, 3),
  (3, 'Leche Flan',           'Rich and creamy Filipino caramel custard',            75.00,  25, 0, 1, 4),
  (3, 'Buko Pandan',          'Classic Filipino coconut pandan dessert',             65.00,  20, 0, 1, 5);

-- ============================================================
-- IMPORTANT: DO NOT add the admin user here.
-- Instead:
--   1. Put generate_hash.php in your lagro-bistro/ folder
--   2. Visit http://localhost/lagro-bistro/generate_hash.php
--   3. Copy the INSERT SQL it shows and run it here
--   4. Delete generate_hash.php after
-- This avoids bcrypt hash escaping errors in phpMyAdmin!
-- ============================================================
