<?php
require_once '../includes/session.php';
header('Content-Type: application/json');
requireLogin();

$userId = (int)$_SESSION['user_id'];
$method = $_SERVER['REQUEST_METHOD'];

// GET — fetch cart + count
if ($method === 'GET') {
    $stmt = $pdo->prepare(
        "SELECT c.product_id, c.quantity, c.customization,
                p.name, p.price, p.image_path, p.stock_quantity
         FROM   cart c
         JOIN   products p ON c.product_id = p.id
         WHERE  c.user_id = ?
         ORDER  BY c.added_at ASC"
    );
    $stmt->execute([$userId]);
    $items = $stmt->fetchAll();
    $count = (int)array_sum(array_column($items, 'quantity'));
    echo json_encode(['items' => $items, 'count' => $count]);
    exit;
}

// POST — add / increment quantity
if ($method === 'POST') {
    $data          = json_decode(file_get_contents('php://input'), true);
    $productId     = (int)($data['product_id']   ?? 0);
    $qty           = max(1, (int)($data['quantity'] ?? 1));
    $customization =       $data['customization'] ?? '';

    if ($productId < 1) {
        echo json_encode(['success' => false, 'message' => 'Invalid product']);
        exit;
    }

    // Verify product exists and is available
    $chk = $pdo->prepare(
        "SELECT id FROM products WHERE id = ? AND is_available = 1"
    );
    $chk->execute([$productId]);
    if (!$chk->fetch()) {
        echo json_encode(['success' => false, 'message' => 'Product not available']);
        exit;
    }

    $stmt = $pdo->prepare(
        "INSERT INTO cart (user_id, product_id, quantity, customization)
         VALUES (?, ?, ?, ?)
         ON DUPLICATE KEY UPDATE
           quantity      = quantity + VALUES(quantity),
           customization = VALUES(customization)"
    );
    $stmt->execute([$userId, $productId, $qty, $customization]);
    echo json_encode(['success' => true]);
    exit;
}

// PUT — set exact quantity (0 removes the item)
if ($method === 'PUT') {
    $data      = json_decode(file_get_contents('php://input'), true);
    $productId = (int)($data['product_id'] ?? 0);
    $qty       = (int)($data['quantity']   ?? 0);

    if ($qty < 1) {
        $pdo->prepare(
            "DELETE FROM cart WHERE user_id = ? AND product_id = ?"
        )->execute([$userId, $productId]);
    } else {
        $pdo->prepare(
            "UPDATE cart SET quantity = ? WHERE user_id = ? AND product_id = ?"
        )->execute([$qty, $userId, $productId]);
    }
    echo json_encode(['success' => true]);
    exit;
}

// DELETE — remove one item
if ($method === 'DELETE') {
    $data      = json_decode(file_get_contents('php://input'), true);
    $productId = (int)($data['product_id'] ?? 0);
    $pdo->prepare(
        "DELETE FROM cart WHERE user_id = ? AND product_id = ?"
    )->execute([$userId, $productId]);
    echo json_encode(['success' => true]);
    exit;
}

http_response_code(405);
echo json_encode(['error' => 'Method not allowed']);
