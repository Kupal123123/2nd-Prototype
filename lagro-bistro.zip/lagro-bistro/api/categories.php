<?php
require_once '../includes/db.php';
header('Content-Type: application/json');

echo json_encode(
    $pdo->query(
        "SELECT * FROM categories ORDER BY sort_order ASC"
    )->fetchAll()
);
