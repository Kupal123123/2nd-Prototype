<?php
require_once '../includes/session.php';
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

$data     = json_decode(file_get_contents('php://input'), true);
$login    = trim($data['login']    ?? '');
$password =      $data['password'] ?? '';

if (!$login || !$password) {
    echo json_encode(['success' => false, 'message' => 'All fields are required']);
    exit;
}

$stmt = $pdo->prepare(
    "SELECT * FROM users WHERE email = ? OR username = ?"
);
$stmt->execute([$login, $login]);
$user = $stmt->fetch();

if (!$user) {
    echo json_encode(['success' => false, 'message' => 'Invalid credentials']);
    exit;
}

if ((int)$user['is_banned'] === 1) {
    $reason = $user['ban_reason'] ? ' Reason: ' . $user['ban_reason'] : '';
    echo json_encode([
        'success' => false,
        'message' => 'Your account has been banned.' . $reason
    ]);
    exit;
}

if (!password_verify($password, $user['password'])) {
    echo json_encode(['success' => false, 'message' => 'Invalid credentials']);
    exit;
}

// Start session
$_SESSION['user_id'] = $user['id'];

echo json_encode([
    'success' => true,
    'user'    => [
        'id'        => $user['id'],
        'full_name' => $user['full_name'],
        'username'  => $user['username'],
        'role'      => $user['role'],
        'email'     => $user['email'],
    ],
    'theme' => $user['theme_preference'] ?? 'dark',
]);
