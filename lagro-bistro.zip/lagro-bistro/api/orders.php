<?php
require_once '../includes/session.php';
header('Content-Type: application/json');
requireLogin();

$userId = (int)$_SESSION['user_id'];
$user   = getCurrentUser();
$method = $_SERVER['REQUEST_METHOD'];

// GET — list orders
if ($method === 'GET') {
    if (!empty($_GET['all']) && $user['role'] === 'admin') {
        // Admin: all orders with customer name
        $stmt = $pdo->query(
            "SELECT o.*, u.full_name AS customer_name
             FROM   orders o
             JOIN   users  u ON o.user_id = u.id
             ORDER  BY o.created_at DESC"
        );
    } else {
        // Customer: own orders only
        $stmt = $pdo->prepare(
            "SELECT * FROM orders WHERE user_id = ? ORDER BY created_at DESC"
        );
        $stmt->execute([$userId]);
    }
    $orders = $stmt->fetchAll();

    // Attach items to each order
    $itemStmt = $pdo->prepare(
        "SELECT * FROM order_items WHERE order_id = ?"
    );
    foreach ($orders as &$order) {
        $itemStmt->execute([$order['id']]);
        $order['items'] = $itemStmt->fetchAll();
    }
    unset($order);

    echo json_encode($orders);
    exit;
}

// POST — place a new order
if ($method === 'POST') {
    $data        = json_decode(file_get_contents('php://input'), true);
    $items       = $data['items']        ?? [];
    $payment     = $data['payment']      ?? 'cash';
    $notes       = $data['notes']        ?? '';
    $subtotal    = (float)($data['subtotal']     ?? 0);
    $deliveryFee = (float)($data['delivery_fee'] ?? 0);
    $total       = (float)($data['total']        ?? 0);

    $validPayments = ['cash', 'gcash', 'credit_card', 'debit_card'];
    if (!in_array($payment, $validPayments, true)) {
        echo json_encode(['success' => false, 'message' => 'Invalid payment method']);
        exit;
    }
    if (empty($items)) {
        echo json_encode(['success' => false, 'message' => 'Cart is empty']);
        exit;
    }

    // Generate unique order number
    $orderNumber = 'LB-' . strtoupper(bin2hex(random_bytes(3))) . '-' . date('md');

    $pdo->beginTransaction();
    try {
        // Insert order
        $pdo->prepare(
            "INSERT INTO orders
               (order_number, user_id, subtotal, delivery_fee, total_amount,
                payment_method, order_type, customer_notes, status)
             VALUES (?, ?, ?, ?, ?, ?, 'pickup', ?, 'pending')"
        )->execute([
            $orderNumber, $userId, $subtotal, $deliveryFee, $total,
            $payment, $notes
        ]);
        $orderId = (int)$pdo->lastInsertId();

        $insItem = $pdo->prepare(
            "INSERT INTO order_items
               (order_id, product_id, product_name, product_price, quantity, subtotal)
             VALUES (?, ?, ?, ?, ?, ?)"
        );
        $decrStock = $pdo->prepare(
            "UPDATE products
             SET stock_quantity = GREATEST(0, stock_quantity - ?)
             WHERE id = ?"
        );

        foreach ($items as $item) {
            $pid   = (int)$item['product_id'];
            $qty   = (int)$item['qty'];
            $price = (float)$item['price'];
            $insItem->execute([
                $orderId, $pid, $item['name'], $price, $qty, $price * $qty
            ]);
            $decrStock->execute([$qty, $pid]);
        }

        // Clear cart
        $pdo->prepare(
            "DELETE FROM cart WHERE user_id = ?"
        )->execute([$userId]);

        $pdo->commit();
        echo json_encode(['success' => true, 'order_number' => $orderNumber]);

    } catch (Exception $e) {
        $pdo->rollBack();
        echo json_encode([
            'success' => false,
            'message' => 'Order failed, please try again'
        ]);
    }
    exit;
}

// PATCH — admin updates status / notes
if ($method === 'PATCH') {
    if ($user['role'] !== 'admin') {
        http_response_code(403);
        echo json_encode(['error' => 'Forbidden']);
        exit;
    }
    $data   = json_decode(file_get_contents('php://input'), true);
    $id     = (int)($data['id']          ?? 0);
    $status =       $data['status']      ?? '';
    $notes  =       $data['admin_notes'] ?? '';

    $valid = ['pending','confirmed','preparing','ready','completed','cancelled'];
    if (!in_array($status, $valid, true)) {
        echo json_encode(['success' => false, 'message' => 'Invalid status']);
        exit;
    }

    $pdo->prepare(
        "UPDATE orders SET status = ?, admin_notes = ? WHERE id = ?"
    )->execute([$status, $notes, $id]);

    echo json_encode(['success' => true]);
    exit;
}

http_response_code(405);
echo json_encode(['error' => 'Method not allowed']);
