<?php
require_once '../includes/session.php';
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

$data         = json_decode(file_get_contents('php://input'), true);
$full_name    = trim($data['full_name'] ?? '');
$username     = trim($data['username']  ?? '');
$email        = trim($data['email']     ?? '');
$phone        = trim($data['phone']     ?? '');
$lrn          = trim($data['lrn']       ?? '');
$grade        = trim($data['grade']     ?? '');
$section      = trim($data['section']   ?? '');
$password     = $data['password']       ?? '';
$confirm      = $data['confirm']        ?? '';

// Validation
if (!$full_name || !$username || !$email || !$password || !$confirm) {
    echo json_encode(['success' => false, 'message' => 'All fields are required']);
    exit;
}
if (strlen($password) < 8) {
    echo json_encode([
        'success' => false,
        'message' => 'Password must be at least 8 characters'
    ]);
    exit;
}
if ($password !== $confirm) {
    echo json_encode([
        'success' => false,
        'message' => 'Passwords do not match'
    ]);
    exit;
}
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo json_encode(['success' => false, 'message' => 'Invalid email address']);
    exit;
}
if (!preg_match('/^[a-zA-Z0-9_]{3,30}$/', $username)) {
    echo json_encode([
        'success' => false,
        'message' => 'Username must be 3-30 characters (letters, numbers, underscores only)'
    ]);
    exit;
}

// Check duplicate
$stmt = $pdo->prepare(
    "SELECT id FROM users WHERE email = ? OR username = ?"
);
$stmt->execute([$email, $username]);
if ($stmt->fetch()) {
    echo json_encode([
        'success' => false,
        'message' => 'Email or username already exists'
    ]);
    exit;
}

// Insert
$hash = password_hash($password, PASSWORD_BCRYPT, ['cost' => 10]);
$stmt = $pdo->prepare(
    "INSERT INTO users (username, email, password, full_name, phone, lrn, grade, section, role)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'customer')"
);
$stmt->execute([$username, $email, $hash, $full_name, $phone, $lrn, $grade, $section]);
$id = (int)$pdo->lastInsertId();

$_SESSION['user_id'] = $id;

echo json_encode([
    'success' => true,
    'user'    => [
        'id'        => $id,
        'full_name' => $full_name,
        'username'  => $username,
        'role'      => 'customer',
        'email'     => $email,
        'lrn'       => $lrn,
        'grade'     => $grade,
        'section'   => $section,
    ],
]);

