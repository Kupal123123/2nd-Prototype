<?php
require_once '../includes/session.php';
header('Content-Type: application/json');
requireModOrAdmin();

$actor  = getCurrentUser();
$method = $_SERVER['REQUEST_METHOD'];

// GET — list all users
if ($method === 'GET') {
    $stmt = $pdo->query(
        "SELECT id, username, email, full_name, phone,
                role, is_banned, ban_reason, created_at
         FROM   users
         ORDER  BY created_at ASC"
    );
    echo json_encode($stmt->fetchAll());
    exit;
}

// PATCH — ban/unban or role change
if ($method === 'PATCH') {
    $data     = json_decode(file_get_contents('php://input'), true);
    $targetId = (int)($data['user_id'] ?? 0);

    if ($targetId === (int)$actor['id']) {
        echo json_encode([
            'success' => false,
            'message' => 'You cannot modify your own account here'
        ]);
        exit;
    }

    // ── Role change ────────────────────────────────────
    if (isset($data['role'])) {
        $role  = $data['role'];
        $valid = ['customer', 'moderator', 'admin', 'owner'];

        if (!in_array($role, $valid, true)) {
            echo json_encode(['success' => false, 'message' => 'Invalid role']);
            exit;
        }
        // Only admins can assign admin or owner roles
        if (($role === 'admin' || $role === 'owner') && $actor['role'] !== 'admin') {
            echo json_encode([
                'success' => false,
                'message' => 'Only admins can assign admin or owner roles'
            ]);
            exit;
        }

        $pdo->prepare(
            "UPDATE users SET role = ? WHERE id = ?"
        )->execute([$role, $targetId]);

        echo json_encode(['success' => true]);
        exit;
    }

    // ── Ban / Unban ────────────────────────────────────
    if (isset($data['ban'])) {
        $banned = $data['ban'] ? 1 : 0;
        $reason = trim($data['reason'] ?? '');

        $pdo->prepare(
            "UPDATE users SET is_banned = ?, ban_reason = ? WHERE id = ?"
        )->execute([$banned, $reason, $targetId]);

        $pdo->prepare(
            "INSERT INTO ban_log (user_id, action, reason, performed_by)
             VALUES (?, ?, ?, ?)"
        )->execute([
            $targetId,
            $banned ? 'ban' : 'unban',
            $reason,
            $actor['id']
        ]);

        echo json_encode(['success' => true]);
        exit;
    }

    echo json_encode(['success' => false, 'message' => 'Nothing to update']);
    exit;
}

http_response_code(405);
echo json_encode(['error' => 'Method not allowed']);
