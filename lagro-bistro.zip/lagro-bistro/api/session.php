<?php
require_once '../includes/session.php';
header('Content-Type: application/json');

$method = $_SERVER['REQUEST_METHOD'];

// GET — return current user + theme
if ($method === 'GET') {
    $user = getCurrentUser();
    echo json_encode([
        'user'  => $user ? [
            'id'        => $user['id'],
            'full_name' => $user['full_name'],
            'username'  => $user['username'],
            'role'      => $user['role'],
            'email'     => $user['email'],
        ] : null,
        'theme' => $user['theme_preference'] ?? 'dark',
    ]);
    exit;
}

// DELETE — logout
if ($method === 'DELETE') {
    session_destroy();
    echo json_encode(['success' => true]);
    exit;
}

// PATCH — save theme preference
if ($method === 'PATCH') {
    requireLogin();
    $data  = json_decode(file_get_contents('php://input'), true);
    if (isset($data['theme'])) {
        $theme = in_array($data['theme'], ['dark', 'light'], true)
            ? $data['theme'] : 'dark';
        $pdo->prepare(
            "UPDATE users SET theme_preference = ? WHERE id = ?"
        )->execute([$theme, $_SESSION['user_id']]);
    }
    echo json_encode(['success' => true]);
    exit;
}

http_response_code(405);
echo json_encode(['error' => 'Method not allowed']);
