<?php
require_once '../includes/session.php';
header('Content-Type: application/json');

// Support _method override for multipart/form-data PUT
$method = $_SERVER['REQUEST_METHOD'];
if ($method === 'POST' && isset($_POST['_method'])) {
    $method = strtoupper($_POST['_method']);
}

// ── GET — public, no auth needed ──────────────────────
if ($method === 'GET') {
    $best = !empty($_GET['best_sellers']);
    $sql  = "SELECT p.*, c.name AS category_name
             FROM   products p
             LEFT   JOIN categories c ON p.category_id = c.id
             WHERE  p.is_available = 1"
          . ($best ? " AND p.is_best_seller = 1" : "")
          . " ORDER BY p.sort_order ASC, p.name ASC";
    echo json_encode($pdo->query($sql)->fetchAll());
    exit;
}

// All other methods require admin
requireRole('admin');

$uploadDir = __DIR__ . '/../uploads/products/';
if (!is_dir($uploadDir)) {
    mkdir($uploadDir, 0755, true);
}

/**
 * Handle image upload, return relative path or null
 */
function handleUpload(string $uploadDir): ?string {
    if (!isset($_FILES['image']) || $_FILES['image']['error'] !== UPLOAD_ERR_OK) {
        return null;
    }
    $allowed = ['jpg','jpeg','png','gif','webp'];
    $ext     = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, $allowed, true)) {
        return null;
    }
    $filename = 'img_' . uniqid('', true) . '.' . $ext;
    $dest     = $uploadDir . $filename;
    if (move_uploaded_file($_FILES['image']['tmp_name'], $dest)) {
        return 'uploads/products/' . $filename;
    }
    return null;
}

// ── POST — create product ──────────────────────────────
if ($method === 'POST') {
    $imgPath = handleUpload($uploadDir);
    $pdo->prepare(
        "INSERT INTO products
           (category_id, name, description, price, image_path,
            stock_quantity, is_best_seller, is_available)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)"
    )->execute([
        (int)$_POST['category_id'],
        trim($_POST['name']),
        trim($_POST['description'] ?? ''),
        (float)$_POST['price'],
        $imgPath,
        (int)$_POST['stock_quantity'],
        isset($_POST['is_best_seller']) && $_POST['is_best_seller'] === '1' ? 1 : 0,
        isset($_POST['is_available'])   && $_POST['is_available']   === '1' ? 1 : 0,
    ]);
    echo json_encode(['success' => true, 'id' => (int)$pdo->lastInsertId()]);
    exit;
}

// ── PUT — update product ───────────────────────────────
if ($method === 'PUT') {
    $id      = (int)($_GET['id'] ?? 0);
    $imgPath = handleUpload($uploadDir);

    $fields = [
        'category_id   = ?',
        'name          = ?',
        'description   = ?',
        'price         = ?',
        'stock_quantity= ?',
        'is_best_seller= ?',
        'is_available  = ?',
    ];
    $params = [
        (int)$_POST['category_id'],
        trim($_POST['name']),
        trim($_POST['description'] ?? ''),
        (float)$_POST['price'],
        (int)$_POST['stock_quantity'],
        isset($_POST['is_best_seller']) && $_POST['is_best_seller'] === '1' ? 1 : 0,
        isset($_POST['is_available'])   && $_POST['is_available']   === '1' ? 1 : 0,
    ];

    if ($imgPath !== null) {
        $fields[] = 'image_path = ?';
        $params[] = $imgPath;
    }
    $params[] = $id;

    $pdo->prepare(
        "UPDATE products SET " . implode(', ', $fields) . " WHERE id = ?"
    )->execute($params);

    echo json_encode(['success' => true]);
    exit;
}

// ── DELETE — remove product ────────────────────────────
if ($method === 'DELETE') {
    $data = json_decode(file_get_contents('php://input'), true);
    $id   = (int)($data['id'] ?? 0);

    // Prevent deletion if product has order history
    $chk = $pdo->prepare(
        "SELECT COUNT(*) FROM order_items WHERE product_id = ?"
    );
    $chk->execute([$id]);
    if ((int)$chk->fetchColumn() > 0) {
        echo json_encode([
            'success' => false,
            'message' => 'Cannot delete: product has order history. Disable it instead.'
        ]);
        exit;
    }

    $pdo->prepare("DELETE FROM products WHERE id = ?")->execute([$id]);
    echo json_encode(['success' => true]);
    exit;
}

http_response_code(405);
echo json_encode(['error' => 'Method not allowed']);
