<?php
/**
 * LAGRO BISTRO - Password Hash Generator
 * 
 * STEP 1: Put this file in your lagro-bistro/ folder
 * STEP 2: Visit http://localhost/lagro-bistro/generate_hash.php
 * STEP 3: Copy the INSERT SQL shown and run it in phpMyAdmin
 * STEP 4: DELETE this file after setup!
 */

$passwords = [
    'Admin@1234'    => 'admin',
    'Mod@1234'      => 'moderator',
];

echo '<pre style="font-family:monospace;font-size:14px;padding:20px;background:#1a1a1a;color:#f0e6d3">';
echo "=== LAGRO BISTRO - Run these SQL commands in phpMyAdmin ===\n\n";
echo "USE lagro_bistro;\n\n";

foreach ($passwords as $pass => $role) {
    $hash = password_hash($pass, PASSWORD_BCRYPT, ['cost' => 10]);
    if ($role === 'admin') {
        echo "-- Admin account (password: {$pass})\n";
        echo "INSERT INTO users (username, email, password, full_name, role) VALUES (\n";
        echo "  'admin',\n";
        echo "  'admin@lagrobistro.com',\n";
        echo "  '{$hash}',\n";
        echo "  'Admin User',\n";
        echo "  'admin'\n";
        echo ");\n\n";
    } else {
        echo "-- Moderator account (password: {$pass})\n";
        echo "INSERT INTO users (username, email, password, full_name, role) VALUES (\n";
        echo "  'moderator',\n";
        echo "  'mod@lagrobistro.com',\n";
        echo "  '{$hash}',\n";
        echo "  'Moderator User',\n";
        echo "  'moderator'\n";
        echo ");\n\n";
    }
}

echo "-- After running above, DELETE this file!\n";
echo '</pre>';
?>
