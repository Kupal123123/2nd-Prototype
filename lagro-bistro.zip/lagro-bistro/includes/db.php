<?php
// ── Database configuration ──────────────────────────
define('DB_HOST', 'localhost');
define('DB_NAME', 'lagro_bistro');
define('DB_USER', 'root');   // Change if your MySQL user is different
define('DB_PASS', '');       // Change if you have a MySQL password
define('DB_PORT', '3306');

try {
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";port=" . DB_PORT
            . ";dbname=" . DB_NAME . ";charset=utf8mb4",
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ]
    );
} catch (PDOException $e) {
    http_response_code(500);
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Database connection failed. Check includes/db.php']);
    exit;
}
