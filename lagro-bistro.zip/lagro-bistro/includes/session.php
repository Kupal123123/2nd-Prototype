<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once __DIR__ . '/db.php';

function isLoggedIn(): bool {
    return isset($_SESSION['user_id']);
}

function getCurrentUser(): ?array {
    global $pdo;
    if (!isLoggedIn()) return null;
    $stmt = $pdo->prepare(
        "SELECT * FROM users WHERE id = ? AND is_banned = 0"
    );
    $stmt->execute([$_SESSION['user_id']]);
    return $stmt->fetch() ?: null;
}

function requireLogin(): void {
    if (!isLoggedIn()) {
        http_response_code(401);
        echo json_encode(['error' => 'Not authenticated']);
        exit;
    }
}

function requireRole(string $role): void {
    requireLogin();
    $u = getCurrentUser();
    if (!$u || $u['role'] !== $role) {
        http_response_code(403);
        echo json_encode(['error' => 'Forbidden — insufficient permissions']);
        exit;
    }
}

function requireModOrAdmin(): void {
    requireLogin();
    $u = getCurrentUser();
    if (!$u || !in_array($u['role'], ['moderator', 'admin'], true)) {
        http_response_code(403);
        echo json_encode(['error' => 'Forbidden — moderator or admin required']);
        exit;
    }
}
